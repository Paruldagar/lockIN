import { useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabaseClient';
import { TYPES, typeInfo, slot, parseAccomplishment } from '../lib/types';

const todayKey = () => new Date().toISOString().slice(0, 10);
const fmtDate = (d) => d.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' });
const fmtSeconds = (sec) => {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
};
const fmtHMS = (sec) => {
  const h = String(Math.floor(sec / 3600)).padStart(2, '0');
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
  const s = String(Math.floor(sec % 60)).padStart(2, '0');
  return `${h}:${m}:${s}`;
};
const emptyEntry = () => ({ energy: null, planned: {}, done: {}, focus_seconds: 0, sessions: 0 });

function dayPoints(entry, typeWeights) {
  let planned = 0, done = 0;
  Object.keys(entry.planned || {}).forEach((s) => {
    const type = s.split('__')[1];
    const w = typeWeights[type] ?? typeInfo(type)?.weight ?? 0;
    planned += (entry.planned[s] || 0) * w;
  });
  Object.keys(entry.done || {}).forEach((s) => {
    const type = s.split('__')[1];
    const w = typeWeights[type] ?? typeInfo(type)?.weight ?? 0;
    const p = entry.planned[s] || 0;
    const d = entry.done[s] || 0;
    done += Math.min(d, p === 0 ? d : p) * w;
  });
  return { planned, done };
}
function rawDone(entry, typeWeights) {
  let done = 0;
  Object.keys(entry.done || {}).forEach((s) => {
    const type = s.split('__')[1];
    const w = typeWeights[type] ?? typeInfo(type)?.weight ?? 0;
    done += (entry.done[s] || 0) * w;
  });
  return done;
}
function last7Keys() {
  const arr = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    arr.push(d.toISOString().slice(0, 10));
  }
  return arr;
}

export default function Home() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [magicSent, setMagicSent] = useState(false);

  const [subjects, setSubjects] = useState(['GS3', 'Anthropology']);
  const [typeWeights, setTypeWeights] = useState(Object.fromEntries(TYPES.map((t) => [t.key, t.weight])));
  const [entries, setEntries] = useState({}); // dateKey -> entry
  const [tab, setTab] = useState('today');
  const [accomplishText, setAccomplishText] = useState('');
  const [accomplishStatus, setAccomplishStatus] = useState('');
  const [newSubject, setNewSubject] = useState('');

  const [timerRunning, setTimerRunning] = useState(false);
  const [timerElapsed, setTimerElapsed] = useState(0);
  const timerRef = useRef(null);
  const startRef = useRef(null);

  // Mirrors `entries` state so rapid-fire updates (double-tapping a counter,
  // timer stop right after a manual edit) always read the latest values —
  // reading from React state inside these handlers can be one render stale.
  const entriesRef = useRef({});
  useEffect(() => { entriesRef.current = entries; }, [entries]);
  function currentEntry(dateKey) {
    return entriesRef.current[dateKey] || emptyEntry();
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    (async () => {
      const uid = session.user.id;
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', uid).single();
      if (profile) {
        setSubjects(profile.subjects || ['GS3', 'Anthropology']);
        setTypeWeights(profile.type_weights || Object.fromEntries(TYPES.map((t) => [t.key, t.weight])));
      }
      const keys = last7Keys();
      const { data: rows } = await supabase
        .from('entries')
        .select('*')
        .eq('user_id', uid)
        .gte('entry_date', keys[0])
        .lte('entry_date', keys[6]);
      const map = {};
      (rows || []).forEach((r) => {
        map[r.entry_date] = {
          energy: r.energy,
          planned: r.planned || {},
          done: r.done || {},
          focus_seconds: r.focus_seconds || 0,
          sessions: r.sessions || 0,
        };
      });
      setEntries(map);
    })();
  }, [session]);

  const entry = entries[todayKey()] || emptyEntry();

  async function persistEntry(dateKey, patch) {
    const uid = session.user.id;
    const merged = { ...currentEntry(dateKey), ...patch };
    entriesRef.current = { ...entriesRef.current, [dateKey]: merged };
    setEntries(entriesRef.current);
    await supabase.from('entries').upsert(
      {
        user_id: uid,
        entry_date: dateKey,
        energy: merged.energy,
        planned: merged.planned,
        done: merged.done,
        focus_seconds: merged.focus_seconds,
        sessions: merged.sessions,
      },
      { onConflict: 'user_id,entry_date' }
    );
  }
  async function persistProfile(patch) {
    const uid = session.user.id;
    await supabase.from('profiles').upsert({ id: uid, ...patch });
  }

  function updateCounter(s, delta) {
    const today = currentEntry(todayKey());
    const done = { ...(today.done || {}) };
    done[s] = Math.max(0, (done[s] || 0) + delta);
    persistEntry(todayKey(), { done });
  }
  function updateTarget(s, val) {
    const today = currentEntry(todayKey());
    const planned = { ...(today.planned || {}) };
    planned[s] = Math.max(0, parseInt(val) || 0);
    persistEntry(todayKey(), { planned });
  }
  function addOutputForSubject(subject, typeKey) {
    if (!typeKey) return;
    const s = slot(subject, typeKey);
    const today = currentEntry(todayKey());
    const planned = { ...(today.planned || {}) };
    if (!(s in planned)) planned[s] = 1;
    persistEntry(todayKey(), { planned });
  }
  function setEnergy(level) {
    const today = currentEntry(todayKey());
    persistEntry(todayKey(), { energy: today.energy === level ? null : level });
  }

  // timer
  function toggleTimer() {
    if (!timerRunning) {
      setTimerRunning(true);
      startRef.current = Date.now();
      timerRef.current = setInterval(() => setTimerElapsed((entry.focus_seconds || 0) + Math.floor((Date.now() - startRef.current) / 1000)), 1000);
    } else {
      setTimerRunning(false);
      clearInterval(timerRef.current);
      const added = Math.floor((Date.now() - startRef.current) / 1000);
      const today = currentEntry(todayKey());
      persistEntry(todayKey(), { focus_seconds: (today.focus_seconds || 0) + added, sessions: (today.sessions || 0) + 1 });
      setTimerElapsed(0);
    }
  }
  function resetTimer() {
    if (timerRunning) { clearInterval(timerRef.current); setTimerRunning(false); }
    setTimerElapsed(0);
  }

  function computeStreak() {
    let streak = 0;
    let d = new Date();
    while (true) {
      const key = d.toISOString().slice(0, 10);
      const e = entries[key];
      if (e && rawDone(e, typeWeights) > 0) { streak++; d.setDate(d.getDate() - 1); } else break;
    }
    return streak;
  }
  function weeklyAvgCompletion() {
    const keys = last7Keys();
    let total = 0, n = 0;
    keys.forEach((k) => {
      const e = entries[k];
      if (!e) return;
      const { planned, done } = dayPoints(e, typeWeights);
      if (planned > 0) { total += Math.min(done / planned, 1) * 100; n++; }
    });
    return n > 0 ? Math.round(total / n) : 0;
  }

  const { planned: todayPlanned, done: todayDone } = dayPoints(entry, typeWeights);
  const todayPct = todayPlanned > 0 ? Math.round(Math.min(todayDone / todayPlanned, 1) * 100) : rawDone(entry, typeWeights) > 0 ? 100 : 0;

  function handleParse() {
    if (!accomplishText.trim()) { setAccomplishStatus('Type what you got done first.'); return; }
    const result = parseAccomplishment(accomplishText, subjects);
    if (result.length === 0) { setAccomplishStatus("Couldn't match that — log it manually below."); return; }
    const today = currentEntry(todayKey());
    const planned = { ...(today.planned || {}) };
    const done = { ...(today.done || {}) };
    const applied = [];
    result.forEach((item) => {
      const s = slot(item.subject, item.type);
      done[s] = (done[s] || 0) + item.count;
      if (!(s in planned)) planned[s] = done[s];
      const info = typeInfo(item.type);
      applied.push(`${info?.icon || ''} ${item.subject} — ${info?.label || item.type}${item.count > 1 ? ' ×' + item.count : ''}`);
    });
    persistEntry(todayKey(), { planned, done });
    setAccomplishStatus('Logged: ' + applied.join(' · '));
    setAccomplishText('');
  }

  async function sendMagicLink(e) {
    e.preventDefault();
    await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: typeof window !== 'undefined' ? window.location.origin : undefined } });
    setMagicSent(true);
  }

  if (loading) return null;

  if (!session) {
    return (
      <div className="wrap">
        <div className="login-box card">
          <div className="eyebrow">Plan → Study → Produce → Verify → Track</div>
          <h1>Output<span>.</span></h1>
          {magicSent ? (
            <p style={{ marginTop: 16, color: 'var(--text-dim)', fontSize: 13 }}>
              Check {email} for a sign-in link.
            </p>
          ) : (
            <form onSubmit={sendMagicLink}>
              <input type="email" required placeholder="you@college.edu" value={email} onChange={(e) => setEmail(e.target.value)} />
              <button className="btn" type="submit" style={{ width: '100%' }}>Send sign-in link</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="wrap">
      <header>
        <div>
          <div className="eyebrow">Plan → Study → Produce → Verify → Track</div>
          <h1>Output<span>.</span></h1>
        </div>
        <div>
          <div className="date-chip">{fmtDate(new Date()).toUpperCase()}</div>
          <div className="streak">🔥 streak: {computeStreak()} days</div>
          <div className="date-chip" style={{ marginTop: 6 }}>
            <button className="btn secondary" style={{ padding: '4px 8px', fontSize: 10 }} onClick={() => supabase.auth.signOut()}>Sign out</button>
          </div>
        </div>
      </header>

      <nav className="tabs">
        {['today', 'weekly', 'settings'].map((t) => (
          <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>
            {t === 'today' ? 'Today' : t === 'weekly' ? 'Weekly' : 'Subjects & Outputs'}
          </button>
        ))}
      </nav>

      {tab === 'today' && (
        <>
          <div className="card">
            <h2>Today's Output</h2>
            <div className="output-hero">
              <div className="output-number">{todayPct}<sub>%</sub></div>
              <div className="output-sub">
                <span>⏱️ Focus: <b>{fmtSeconds(entry.focus_seconds || 0)}</b></span>
                <span>📚 Sessions: <b>{entry.sessions || 0}</b></span>
                <span>🎯 Points: <b>{todayDone.toFixed(1)} / {todayPlanned.toFixed(1)}</b></span>
              </div>
            </div>
            {todayPlanned > 0 && todayPct < 50 && (
              <div className="bad-day-note">
                That's okay — today's at {todayPct}%. Your weekly average is still {weeklyAvgCompletion()}%. Consistency across the week matters more than any single day.
              </div>
            )}
          </div>

          <div className="card">
            <h2>How's your energy right now?</h2>
            <div className="energy-row">
              {['low', 'medium', 'high'].map((lvl) => (
                <button key={lvl} className={entry.energy === lvl ? 'sel' : ''} onClick={() => setEnergy(lvl)}>
                  {lvl === 'low' ? '🔴 Low' : lvl === 'medium' ? '🟡 Medium' : '🟢 High'}
                </button>
              ))}
            </div>
          </div>

          <div className="card">
            <h2>Focus timer <small>secondary metric</small></h2>
            <div className="timer-row">
              <div className="timer-display">{fmtHMS(timerRunning ? timerElapsed : entry.focus_seconds || 0)}</div>
              <button className="btn" onClick={toggleTimer}>{timerRunning ? 'Stop' : 'Start'}</button>
              <button className="btn secondary" onClick={resetTimer}>Reset</button>
            </div>
          </div>

          <div className="card">
            <h2>The production line <small>set today's targets, log what's done</small></h2>
            {subjects.map((subject) => (
              <div key={subject}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, color: 'var(--teal)', margin: '10px 0 4px' }}>{subject}</div>
                {TYPES.map((t) => {
                  const s = slot(subject, t.key);
                  const p = (entry.planned || {})[s] || 0;
                  const d = (entry.done || {})[s] || 0;
                  if (p === 0 && d === 0) return null;
                  const pct = p > 0 ? Math.min(d / p, 1) * 100 : d > 0 ? 100 : 0;
                  return (
                    <div className="line-row" key={s}>
                      <div className="icon">{t.icon}</div>
                      <div className="name">{t.label}<span className="sub">weight {typeWeights[t.key]}</span></div>
                      <div className="counter">
                        <button onClick={() => updateCounter(s, -1)}>–</button>
                        <span className="n">{d}</span>
                        <button onClick={() => updateCounter(s, 1)}>+</button>
                      </div>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-dim)', textAlign: 'right' }}>
                        of <input className="target-input" type="number" min="0" value={p} onChange={(e) => updateTarget(s, e.target.value)} />
                      </div>
                      <div className="bar-track"><div className="bar-fill" style={{ width: pct + '%' }} /></div>
                    </div>
                  );
                })}
                <select
                  defaultValue=""
                  style={{ marginTop: 6, background: 'var(--panel-alt)', color: 'var(--text-dim)', border: '1px solid var(--line)', borderRadius: 4, fontFamily: 'var(--font-mono)', fontSize: 11, padding: '4px 6px' }}
                  onChange={(e) => { addOutputForSubject(subject, e.target.value); e.target.value = ''; }}
                >
                  <option value="">+ add an output type for today…</option>
                  {TYPES.map((t) => <option key={t.key} value={t.key}>{t.icon} {t.label}</option>)}
                </select>
              </div>
            ))}
          </div>

          <div className="card">
            <h2>What did you actually accomplish? <small>type it, it'll log itself</small></h2>
            <textarea value={accomplishText} onChange={(e) => setAccomplishText(e.target.value)} placeholder="e.g. Finished terrorism topic, revised cyber security, wrote one mains answer and solved 15 PYQs" />
            <div style={{ marginTop: 10, display: 'flex', gap: 10, alignItems: 'center' }}>
              <button className="btn" onClick={handleParse}>Log it</button>
              <div className="accomplish-status">{accomplishStatus}</div>
            </div>
          </div>
        </>
      )}

      {tab === 'weekly' && <WeeklyView entries={entries} typeWeights={typeWeights} subjects={subjects} />}

      {tab === 'settings' && (
        <SettingsView
          subjects={subjects}
          setSubjects={(s) => { setSubjects(s); persistProfile({ subjects: s }); }}
          typeWeights={typeWeights}
          setTypeWeights={(w) => { setTypeWeights(w); persistProfile({ type_weights: w }); }}
          newSubject={newSubject}
          setNewSubject={setNewSubject}
        />
      )}
    </div>
  );
}

function WeeklyView({ entries, typeWeights, subjects }) {
  const keys = last7Keys();
  let totalPlanned = 0, totalDone = 0;
  const cols = keys.map((k) => {
    const e = entries[k] || emptyEntry();
    const { planned, done } = dayPoints(e, typeWeights);
    totalPlanned += planned; totalDone += done;
    const pct = planned > 0 ? Math.round(Math.min(done / planned, 1) * 100) : 0;
    return { k, pct };
  });

  const planVals = [], doneVals = [];
  keys.forEach((k) => {
    const e = entries[k]; if (!e) return;
    const { planned, done } = dayPoints(e, typeWeights);
    if (planned > 0) { planVals.push(planned); doneVals.push(done); }
  });
  let capacityMsg = 'Set daily targets for a few more days and this will start learning your realistic pace.';
  if (doneVals.length >= 2) {
    const avgDone = doneVals.reduce((a, b) => a + b, 0) / doneVals.length;
    const avgPlan = planVals.reduce((a, b) => a + b, 0) / planVals.length;
    capacityMsg = avgPlan > avgDone * 1.15
      ? `You've been planning ~${avgPlan.toFixed(1)} pts/day but completing ~${avgDone.toFixed(1)} pts/day. Try planning nearer ${avgDone.toFixed(1)} pts tomorrow.`
      : `You're planning ~${avgPlan.toFixed(1)} pts/day and landing close to it (~${avgDone.toFixed(1)} pts). Worth holding steady.`;
  }

  const energyStats = ['low', 'medium', 'high'].map((lvl) => {
    const vals = [];
    keys.forEach((k) => {
      const e = entries[k]; if (!e || e.energy !== lvl) return;
      const { planned, done } = dayPoints(e, typeWeights);
      if (planned > 0) vals.push(Math.min(done / planned, 1) * 100);
    });
    return { lvl, avg: vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null };
  });

  return (
    <>
      <div className="card">
        <h2>Last 7 days</h2>
        <div className="week-grid">
          {cols.map(({ k, pct }) => (
            <div className={'day-col' + (k === todayKey() ? ' today' : '')} key={k}>
              <div className="d">{new Date(k + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short' })}</div>
              <div className="pct">{pct}%</div>
            </div>
          ))}
        </div>
        <div className="output-sub">
          <span>🎯 Planned: <b>{totalPlanned.toFixed(1)}</b></span>
          <span>✅ Completed: <b>{totalDone.toFixed(1)}</b></span>
          <span>Overall: <b>{totalPlanned > 0 ? Math.round(Math.min(totalDone / totalPlanned, 1) * 100) : 0}%</b></span>
        </div>
      </div>

      <div className="card">
        <h2>By subject this week</h2>
        {subjects.map((subject) => {
          const counts = {};
          keys.forEach((k) => {
            const e = entries[k]; if (!e) return;
            TYPES.forEach((t) => {
              const s = slot(subject, t.key);
              if (e.done && e.done[s]) counts[t.key] = (counts[t.key] || 0) + e.done[s];
            });
          });
          const tags = Object.keys(counts).map((k) => `${typeInfo(k).icon} ${counts[k]} ${typeInfo(k).label.toLowerCase()}`);
          return (
            <div className="subject-block" key={subject}>
              <h3>{subject}</h3>
              <div className="tags">{tags.length ? tags.map((t, i) => <span key={i}>{t}</span>) : <span>No output logged this week yet</span>}</div>
            </div>
          );
        })}
      </div>

      <div className="card">
        <h2>Your realistic capacity <small>learned from your last 7 days</small></h2>
        <div className="capacity-note">{capacityMsg}</div>
      </div>

      <div className="card">
        <h2>Energy vs. output</h2>
        <div className="energy-stats">
          {energyStats.map(({ lvl, avg }) => (
            <div className="energy-stat" key={lvl}>
              <div className="lv">{lvl === 'low' ? '🔴 Low' : lvl === 'medium' ? '🟡 Medium' : '🟢 High'}</div>
              <div className="avg">{avg !== null ? avg + '%' : '—'}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function SettingsView({ subjects, setSubjects, typeWeights, setTypeWeights, newSubject, setNewSubject }) {
  return (
    <>
      <div className="card">
        <h2>Subjects</h2>
        <div className="chip-list">
          {subjects.map((s) => (
            <div className="chip" key={s}>
              {s}
              <button onClick={() => setSubjects(subjects.filter((x) => x !== s))}>×</button>
            </div>
          ))}
        </div>
        <div className="add-row">
          <input placeholder="Add a subject, e.g. Ethics" value={newSubject} onChange={(e) => setNewSubject(e.target.value)} />
          <button className="btn" onClick={() => { if (newSubject.trim() && !subjects.includes(newSubject.trim())) { setSubjects([...subjects, newSubject.trim()]); setNewSubject(''); } }}>Add</button>
        </div>
      </div>

      <div className="card">
        <h2>Output types & weights <small>weight = how much it counts toward your score</small></h2>
        {TYPES.map((t) => (
          <div className="line-row" style={{ gridTemplateColumns: '26px 1fr 90px' }} key={t.key}>
            <div className="icon">{t.icon}</div>
            <div className="name">{t.label}<span className="sub">{t.group}</span></div>
            <input
              className="target-input"
              style={{ width: 60 }}
              type="number"
              step="0.1"
              min="0"
              value={typeWeights[t.key]}
              onChange={(e) => setTypeWeights({ ...typeWeights, [t.key]: parseFloat(e.target.value) || 0 })}
            />
          </div>
        ))}
      </div>
    </>
  );
}

# Output Tracker — deploy guide

A study-output tracker (weighted outputs, energy tracking, an offline text
parser, weekly capacity learning) with real accounts and cloud sync, ready to
deploy on Vercel — no paid API required.

## 1. Set up Supabase (free)

1. Go to supabase.com → New project. Pick any name/region, set a database password (save it somewhere).
2. Once created, go to **SQL Editor → New query**, paste the contents of `supabase/schema.sql`, and run it. This creates the `profiles` and `entries` tables with row-level security so each student only ever sees their own data.
3. Go to **Project Settings → API**. Copy:
   - `Project URL` → this is `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → this is `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Go to **Authentication → Providers → Email** and make sure "Email OTP / Magic Link" is enabled (it is by default). Students sign in by email link — no passwords to manage.

## 2. Push this folder to GitHub

The "what did you accomplish" box uses a free, offline keyword matcher
(`lib/types.js` → `parseAccomplishment`) — no API key, no per-use cost.
It's less flexible with phrasing than an AI parser would be, but it costs
nothing to run no matter how many students use it.

```bash
cd output-tracker
git init
git add .
git commit -m "initial commit"
# create a new empty repo on github.com, then:
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## 3. Deploy on Vercel

1. Go to vercel.com → New Project → import the GitHub repo you just pushed.
2. Vercel auto-detects Next.js — no build config needed.
3. Under **Environment Variables**, add the two from step 1:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Click Deploy. You'll get a live URL (e.g. `output-tracker.vercel.app`) — that's what you share with students.
5. Any student can visit it, sign in with their email (magic link, no password), and their data is theirs — stored under their own row in Supabase, synced across any device they sign in on.

## 4. Making it feel like an app on a phone

Once deployed, a student can open the URL in their phone browser and use
"Add to Home Screen" (Safari/Chrome) — it'll behave like an installed app.
If you want a proper install prompt and offline support later, that's a
`manifest.json` + service worker addition — ask if you want that built in.

## Local development

```bash
npm install
cp .env.local.example .env.local   # fill in your Supabase URL + anon key
npm run dev
```

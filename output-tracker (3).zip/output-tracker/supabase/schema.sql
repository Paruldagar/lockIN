-- Run this once in your Supabase project's SQL Editor (Supabase dashboard -> SQL Editor -> New query)

create table if not exists profiles (
  id uuid references auth.users on delete cascade primary key,
  subjects jsonb not null default '["GS3","Anthropology"]',
  type_weights jsonb not null default '{
    "lecture":1,"topic":2,"revision":2,"flashcards":1,
    "mains":4,"essay":6,"diagram":3,"notes":2,
    "pyq":0.2,"mcq":0.2,"test":8,"ca":2
  }',
  created_at timestamp with time zone default now()
);

create table if not exists entries (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  entry_date date not null,
  energy text,
  planned jsonb not null default '{}',
  done jsonb not null default '{}',
  focus_seconds integer not null default 0,
  sessions integer not null default 0,
  unique(user_id, entry_date)
);

alter table profiles enable row level security;
alter table entries enable row level security;

create policy "own profile read" on profiles for select using (auth.uid() = id);
create policy "own profile write" on profiles for insert with check (auth.uid() = id);
create policy "own profile update" on profiles for update using (auth.uid() = id);

create policy "own entries read" on entries for select using (auth.uid() = user_id);
create policy "own entries write" on entries for insert with check (auth.uid() = user_id);
create policy "own entries update" on entries for update using (auth.uid() = user_id);

-- auto-create a profile row when someone signs up
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
